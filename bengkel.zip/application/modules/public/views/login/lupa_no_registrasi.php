<div class="row">
  <div class="col-lg-12">
    <p style="text-align:justify">
      Silahkan hubungi admin untuk mendapatkan No.registrasi. Anda akan di berikan beberapa pertanyaan untuk memastikan data itu benar punya anda.

    </p>
    <p>
      Silahkan hub kontak di bawah: <br>
      <i class="fa fa-phone"></i> <?=profile('telepon')?> <br>
      <i class="fa fa-envelope"></i> <?=profile('email')?> <br>
    </p>

    <p>Atau kunjungi alamat bengkel <?=profile('alamat')?> </p>

    <button type="button" class="btn btn-secondary btn-sm btn-block" data-dismiss="modal" aria-label="Close">tutup</button>
  </div>
</div>
