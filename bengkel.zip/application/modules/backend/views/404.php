
<div class="row">
<div class="col-md-12 d-flex align-items-stretch grid-margin">
  <div class="row flex-grow">
    <div class="col-12">
      <div class="card">
        <div class="card-body" style="text-align:center">
          <h3>ERROR 404!</h3>
            <h4>Halaman Tidak Di Temukan!</h4>
            <a href="javascript:history.back()" class="btn btn-info btn-xs"> Kembali Kehalaman Sebelumnya</a>
            <a href="<?=site_url($this->session->userdata('panel').'/home')?>" class="btn btn-danger btn-xs"> <i class="fa fa-home"></i></a>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
